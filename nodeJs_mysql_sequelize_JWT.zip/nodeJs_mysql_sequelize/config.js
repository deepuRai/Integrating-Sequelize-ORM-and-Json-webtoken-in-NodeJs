var mysql      = require('mysql');

var mysqlpool = mysql.createPool({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'techblog'
});
mysqlpool.getConnection(function(err, connection){
if(!err) {
    console.log("Database is connected");
} else {
    console.log("Error while connecting with database");
}
connection.release();
});
module.exports = mysqlpool;