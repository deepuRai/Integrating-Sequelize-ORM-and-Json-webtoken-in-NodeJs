//var connection = require('./../config');
var bcrypt = require('bcrypt-nodejs');
//const Sequelize = require('sequelize');
//const User = require('../models/index');
//const User = db.Sequelize;



module.exports.register=function(req,res){

  //res.send(User);
    var today = new Date();

    var hash = bcrypt.hashSync(req.body.password);
    

    User.create({
      firstName: req.body.firstname,
       lastName: req.body.lastname,
       email: req.body.email,
       password: hash,
       role: req.body.role
      
      })
      .then(function(result){
        res.send(result);
    })
   
}