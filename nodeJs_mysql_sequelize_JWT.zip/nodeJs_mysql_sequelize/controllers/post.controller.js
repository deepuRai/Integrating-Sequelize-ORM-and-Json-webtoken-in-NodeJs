const db = require('../config/db.config.js');
const config = require('../config/config.js');
const Post = db.posts;
var bcrypt = require('bcrypt-nodejs');
var jwt = require('jsonwebtoken');



// Post a Customer
exports.create = (req, res) => { 
 
  // Save to MySQL database
  Post.create({  
    title: req.body.title,
    description: req.body.description
    
  }).then(post => {    
    // Send created customer to client
    res.send(post);
  });
};
 
// FETCH all Customers
exports.findAll = (req, res) => {
  User.findAll().then(users => {
    // Send all customers to Client
    res.send(users);
  });
};
 
// Find a Customer by Id
// exports.findById = (req, res) => {  
//   User.findById(req.params.userId).then(user => {
//     res.send(user);
//   })
// };
 
// Update a Customer
exports.update = (req, res) => {
  const id = req.params.userId;
  User.update( { firstname: req.body.firstname, lastname: req.body.lastname, age: req.body.age }, 
           { where: {id: req.params.userId} }
           ).then(() => {
           res.status(200).send("updated successfully a customer with id = " + id);
           });
};
 
// Delete a Customer by Id
exports.delete = (req, res) => {
  const id = req.params.userId;
  User.destroy({
    where: { id: id }
  }).then(() => {
    res.status(200).send('deleted successfully a customer with id = ' + id);
  });
};


