const db = require('../config/db.config.js');
const config = require('../config/config.js');
const User = db.users;
var bcrypt = require('bcrypt-nodejs');
var jwt = require('jsonwebtoken');


exports.signin = (req, res) => {
  console.log("Sign-In");

  console.log(req.body.firstname);
  
  User.findOne({
    where: {
      firstname: req.body.firstname
    }
  }).then(user => {
    if (!user) {
      return res.status(404).send('User Not Found.');
    }
 
    var passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
    if (!passwordIsValid) {
      return res.status(401).send({ auth: false, accessToken: null, reason: "Invalid Password!" });
    }
    
    var token = jwt.sign({ id: user.id }, config.secret, {
      expiresIn: 86400 // expires in 24 hours
    });
    
    res.status(200).send({ auth: true, accessToken: token });
    
  }).catch(err => {
    res.status(500).send('Error -> ' + err);
  });
}

// Post a Customer
exports.create = (req, res) => { 

    console.log(req.body);
    
    var hash = bcrypt.hashSync(req.body.password); 
  // Save to MySQL database
  User.create({  
    firstName: req.body.firstname,
    lastName: req.body.lastname,
    email: req.body.email,
    password: hash,
    role: req.body.role
  }).then(user => {    
    // Send created customer to client
    res.send(user);
  });
};
 
// FETCH all Customers
exports.findAll = (req, res) => {
  User.findAll().then(users => {
    // Send all customers to Client
    res.send(users);
  });
};
 
// Find a Customer by Id
// exports.findById = (req, res) => {  
//   User.findById(req.params.userId).then(user => {
//     res.send(user);
//   })
// };
 
// Update a Customer
exports.update = (req, res) => {
  const id = req.params.userId;
  User.update( { firstname: req.body.firstname, lastname: req.body.lastname, age: req.body.age }, 
           { where: {id: req.params.userId} }
           ).then(() => {
           res.status(200).send("updated successfully a customer with id = " + id);
           });
};
 
// Delete a Customer by Id
exports.delete = (req, res) => {
  const id = req.params.userId;
  User.destroy({
    where: { id: id }
  }).then(() => {
    res.status(200).send('deleted successfully a customer with id = ' + id);
  });
};


